package com.ubs.mvw.pcf.oauthgateway

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class OauthgatewayApplication

fun main(args: Array<String>) {
	runApplication<OauthgatewayApplication>(*args)
}
