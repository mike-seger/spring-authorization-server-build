package com.ubs.mvw.pcf.oauthgateway

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OauthgatewayApplicationTests {

	@Test
	fun contextLoads() {
	}

}
