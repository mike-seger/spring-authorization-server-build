package com.ubs.mvw.pcf.oauthgw

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OauthgwApplicationTests {

	@Test
	fun contextLoads() {
	}

}
