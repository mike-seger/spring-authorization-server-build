package com.ubs.mvw.pcf.oauthgw

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class OauthgwApplication

fun main(args: Array<String>) {
	runApplication<OauthgwApplication>(*args)
}
