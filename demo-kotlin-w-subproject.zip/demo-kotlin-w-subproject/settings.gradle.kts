rootProject.name = "demo"

include("subproject1")