apply {
    plugin("org.springframework.boot")
}