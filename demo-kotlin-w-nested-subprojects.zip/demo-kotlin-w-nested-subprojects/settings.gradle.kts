rootProject.name = "demo"

include("subproject1", "subproject2:subproject3")